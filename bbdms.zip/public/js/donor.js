$(document).ready(function () {
    $('#datatable-for-donors').DataTable();
});